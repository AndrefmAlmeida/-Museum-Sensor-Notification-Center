import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import javax.swing.JOptionPane;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

@SuppressWarnings("deprecation")
public class MongoToSql {

	static MongoClient mongoClient;
	static DB db;
	static DBCollection mongocol_treated;
	static String mongo_host = new String();
	static String mongo_database = new String();
	static String mongo_collection_treated = new String();
	static Connection con;
	static String limiteTemperaturaMax = new String();
	static String limiteTemperaturaMin = new String();
	static String limiteHumidadeMax = new String();
	static String limiteHumidadeMin = new String();
	static String limiteLuminosidadeMax = new String();
	static String margemPico = new String();
	static String timeAfterAlert = new String();
	static String percentagemMargem = new String();
	static DBObject obj;
	String rondaAtiva = "0";
	static Long milisegTmp = 0L;
	static Long milisegHum = 0L;
	static Long milisegCell = 0L;
	static Long milisegMov = 0L;


	public static void main(String[] args) {

		try {
			Properties p = new Properties();
			p.load(new FileInputStream("C:\\Users\\Andre\\Desktop\\sid\\java\\cloudToMongo.ini"));
			mongo_host = p.getProperty("mongo_host");
			mongo_database = p.getProperty("mongo_database");
			mongo_collection_treated = p.getProperty("mongo_collection_treated");
			limiteTemperaturaMax = p.getProperty("limiteTemperaturaMax");
			limiteTemperaturaMin = p.getProperty("limiteTemperaturaMin");
			limiteHumidadeMax = p.getProperty("limiteHumidadeMax");
			limiteHumidadeMin = p.getProperty("limiteHumidadeMin");
			limiteLuminosidadeMax = p.getProperty("limiteLuminosidadeMax");
			margemPico = p.getProperty("margemPico");
			timeAfterAlert = p.getProperty("timeAfterAlert");
			percentagemMargem = p.getProperty("percentagemMargem");

		} catch (Exception e) {

			System.out.println("Error reading CloudToMongo.ini file " + e);
			JOptionPane.showMessageDialog(null, "The CloudToMongo.ini file wasn't found.", "CloudToMongo",
					JOptionPane.ERROR_MESSAGE);
		}

		insertSistema(con, limiteTemperaturaMax, limiteTemperaturaMin, limiteHumidadeMax, limiteHumidadeMin, limiteLuminosidadeMax, margemPico, timeAfterAlert, percentagemMargem);
		new MongoToSql().connectMongo();
		new MongoToSql().readCollection();
	}



	public void connectMongo() {
		mongoClient = new MongoClient(new MongoClientURI(mongo_host));
		db = mongoClient.getDB(mongo_database);
		mongocol_treated = db.getCollection(mongo_collection_treated);
	}


	//	M�todo que faz o acesso � cole��o dos dados tratados e l� linha a linha, � medida que forem surgindo dados na mesma. 

	public void readCollection () {
		while(true) {
			DBCursor cursor = mongocol_treated.find();
			while (cursor.hasNext()) {
				obj = cursor.next();
				mongocol_treated.remove(obj);
				insertMedSens(con, obj, obj.get("tmp").toString(), obj.get("hum").toString(), obj.get("cell").toString(), obj.get("mov").toString(), (obj.get("dat").toString()+" "+obj.get("tim").toString()));
				checkAlertas(obj);
			}
		}
	}


	public void checkAlertas (DBObject obj) {
		checkAlertaTmp(obj);
		checkAlertaHum(obj);
		checkAlertaCell(obj);
		checkAlertaMov(obj);
	}


	public void checkAlertaTmp (DBObject obj){
		if (System.currentTimeMillis()>milisegTmp+Long.parseLong(timeAfterAlert)) {
			if (verifyTmp(obj)){
				if (Double.parseDouble(obj.get("tmp").toString()) >= (Double.parseDouble(limiteTemperaturaMax)-Double.parseDouble(limiteTemperaturaMax)*Double.parseDouble(percentagemMargem)) || Double.parseDouble(obj.get("tmp").toString()) <= (Double.parseDouble(limiteTemperaturaMin)+Double.parseDouble(limiteTemperaturaMax)*Double.parseDouble(percentagemMargem))) {
					//				Check if its red alert
					if (Double.parseDouble(obj.get("tmp").toString()) >= Double.parseDouble(limiteTemperaturaMax) || Double.parseDouble(obj.get("tmp").toString()) <= Double.parseDouble(limiteTemperaturaMin)) {
						if (Double.parseDouble(obj.get("tmp").toString()) >= Double.parseDouble(limiteTemperaturaMax)) {
							insertAlerta(con, obj, (obj.get("dat").toString()+" "+obj.get("tim").toString()), "Tmp", obj.get("tmp").toString(), "RED Alert: Temperatura acima dos " + limiteTemperaturaMax + " graus!", "1", "0");
						} else {
							insertAlerta(con, obj, (obj.get("dat").toString()+" "+obj.get("tim").toString()), "Tmp", obj.get("tmp").toString(), "RED Alert: Temperatura abaixo dos " + limiteTemperaturaMin + " graus!", "1", "0");
						}
						//			Else its yellow alert
					} else {
						if (Double.parseDouble(obj.get("tmp").toString()) >= (Double.parseDouble(limiteTemperaturaMax)-Double.parseDouble(limiteTemperaturaMax)*Double.parseDouble(percentagemMargem))) {
							insertAlerta(con, obj, (obj.get("dat").toString()+" "+obj.get("tim").toString()), "Tmp", obj.get("tmp").toString(), "YELLOW Alert: Temperatura acima dos " + (Double.parseDouble(limiteTemperaturaMax)-Double.parseDouble(limiteTemperaturaMax)*Double.parseDouble(percentagemMargem)) + " graus!", "0", "0");
						} else {
							insertAlerta(con, obj, (obj.get("dat").toString()+" "+obj.get("tim").toString()), "Tmp", obj.get("tmp").toString(), "YELLOW Alert: Temperatura abaixo dos " + (Double.parseDouble(limiteTemperaturaMin)+Double.parseDouble(limiteTemperaturaMax)*Double.parseDouble(percentagemMargem)) + " graus!", "0", "0");
						}
					}
				}
				milisegTmp = System.currentTimeMillis();
			}
		}
	}



	public void checkAlertaHum (DBObject obj){
		if (System.currentTimeMillis()>milisegHum+Long.parseLong(timeAfterAlert)) {
			if (verifyHum(obj)){
				if (Double.parseDouble(obj.get("hum").toString()) >= (Double.parseDouble(limiteHumidadeMax)-Double.parseDouble(limiteHumidadeMax)*Double.parseDouble(percentagemMargem)) || Double.parseDouble(obj.get("hum").toString()) <= (Double.parseDouble(limiteHumidadeMin)+Double.parseDouble(limiteHumidadeMax)*Double.parseDouble(percentagemMargem))) {
					//				Check if its red alert
					if (Double.parseDouble(obj.get("hum").toString()) >= Double.parseDouble(limiteHumidadeMax) || Double.parseDouble(obj.get("hum").toString()) <= Double.parseDouble(limiteHumidadeMin)) {
						if (Double.parseDouble(obj.get("hum").toString()) >= Double.parseDouble(limiteHumidadeMax)) {
							insertAlerta(con, obj, (obj.get("dat").toString()+" "+obj.get("tim").toString()), "hum", obj.get("hum").toString(), "RED Alert: Humidade acima dos "+ limiteHumidadeMax + "!", "1", "0");
						} else {
							insertAlerta(con, obj, (obj.get("dat").toString()+" "+obj.get("tim").toString()), "hum", obj.get("hum").toString(), "RED Alert: Humidade abaixo dos "+ limiteHumidadeMin + "!", "1", "0");
						}
						//			Else its yellow alert
					} else {
						if (Double.parseDouble(obj.get("hum").toString()) >= (Double.parseDouble(limiteHumidadeMax)-Double.parseDouble(limiteHumidadeMax)*Double.parseDouble(percentagemMargem))) {
							insertAlerta(con, obj, (obj.get("dat").toString()+" "+obj.get("tim").toString()), "hum", obj.get("hum").toString(), "YELLOW Alert: Humidade acima dos " + (Double.parseDouble(limiteHumidadeMax)-Double.parseDouble(limiteHumidadeMax)*Double.parseDouble(percentagemMargem)) + "!", "0", "0");
						} else {
							insertAlerta(con, obj, (obj.get("dat").toString()+" "+obj.get("tim").toString()), "hum", obj.get("hum").toString(), "YELLOW Alert: Humidade abaixo dos " + (Double.parseDouble(limiteHumidadeMin)+Double.parseDouble(limiteHumidadeMax)*Double.parseDouble(percentagemMargem)) + "!", "0", "0");
						}
					}
				}
				milisegHum = System.currentTimeMillis();
			}
		}
	}


	public void checkAlertaCell (DBObject obj){
		if (System.currentTimeMillis()>milisegCell+Long.parseLong(timeAfterAlert)) {
			if (verifyCell(obj)){
				if (Double.parseDouble(obj.get("cell").toString()) >= (Double.parseDouble(limiteLuminosidadeMax))) {
					getRondaAtiva("ronda");
					getRondaAtiva("rondaextra");
					if (rondaAtiva.equals("0")) {
						insertAlerta(con, obj, (obj.get("dat").toString()+" "+obj.get("tim").toString()), "cell", obj.get("cell").toString(), "RED Alert: Luminosidade acima dos "+ limiteLuminosidadeMax + "!", "1", "0");
					}
					rondaAtiva = "0";
				}
				rondaAtiva = "0";
				milisegCell = System.currentTimeMillis();
			}
		}
	}



	public void checkAlertaMov (DBObject obj){
		if (System.currentTimeMillis()>milisegMov+Long.parseLong(timeAfterAlert)) {
			if (verifyMov(obj)){
				if (Double.parseDouble(obj.get("mov").toString()) > 0) {
					getRondaAtiva("ronda");
					getRondaAtiva("rondaextra");
					if (rondaAtiva.equals("0")) {
						insertAlerta(con, obj, (obj.get("dat").toString()+" "+obj.get("tim").toString()), "mov", obj.get("mov").toString(), "RED Alert: Foi detectado movimento!", "1", "0");
					}
					rondaAtiva = "0";
				}
				rondaAtiva = "0";
				milisegMov = System.currentTimeMillis();
			}
		}
	}


	public boolean verifyTmp( DBObject obj) {
		if(isNumeric(obj.get("tmp").toString())){	
			return true;
		}else {
			return false;
		}
	}

	public boolean verifyHum(DBObject obj) {
		if(isNumeric(obj.get("hum").toString()) && (Double.parseDouble(obj.get("hum").toString())) > 0) {
			return true;
		}else{
			return false;
		}
	}

	public boolean verifyCell(DBObject obj) {
		if(isNumeric(obj.get("cell").toString())) {
			if((Double.parseDouble(obj.get("cell").toString())) > 0.0) {
				return true;
			}
			return false;
		}else{
			return false;
		}
	}

	public boolean verifyMov(DBObject obj) {
		try {
			if(isNumeric(obj.get("mov").toString()) && (Integer.parseInt(obj.get("mov").toString())) == 0 || (Integer.parseInt(obj.get("mov").toString())) == 1 ) {
				return true;
			}else{
				return false;
			}
		}catch(NumberFormatException e) {
			return false;
		}
	}

	public static boolean isNumeric(String str) { 
		try {  
			Double.parseDouble(str);  
			return true;
		} catch(Exception e){
			return false;  
		}  
	}


	public void getRondaAtiva (String r) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/grupo36_mongodb","root","root");  
			Statement stmt = con.createStatement();

			stmt.executeQuery("SELECT * FROM " + r + "");
			ResultSet gr = stmt.getResultSet();
			while (gr.next()) {
				gr.getString("rondaAtiva");
				if (gr.getString("rondaAtiva").equals("1")) {
					rondaAtiva = "1";
				} 
			}

		}catch(Exception e){ 
			e.printStackTrace();
		} 
	}


	public void insertMedSens (Connection con, DBObject obj, String tmp, String hum, String cell, String mov, String dat) {
		try {
			Class.forName("com.mysql.jdbc.Driver"); 
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/grupo36_mongodb","root","root");
			Statement stmt = con.createStatement();
			stmt.execute("insert into medicoes_sensores (valorT, valorH, valorL, valorM, dataHoraMedicao) values ("+ tmp +", "+ hum +", "+ cell +", "+ mov +", \""+ dat +"\")");


		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void insertAlerta (Connection con, DBObject obj, String dat, String tiposensor, String valormed, String desc, String controlo, String extra) {
		try {
			Class.forName("com.mysql.jdbc.Driver"); 
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/grupo36_mongodb","root","root");
			Statement stmt = con.createStatement();
			stmt.execute("INSERT INTO `alerta` (`ID`, `dataHoraMedicao`, `tipoSensor`, `valorMedicao`, `descricao`, `controlo`, `extra`) VALUES (NULL, "+"'"+ dat + "', '" + tiposensor + "', '" + valormed + "', '" + desc + "', '" + controlo + "', '" + extra + "')"); 

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void insertSistema (Connection con, String tmpmax, String tmpmin, String hummax, String hummin, String cell, String margempico, String time, String margempercentagem) {
		try {
			Class.forName("com.mysql.jdbc.Driver"); 
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/grupo36_mongodb","root","root");
			Statement stmt = con.createStatement();
			stmt.execute("TRUNCATE TABLE `sistema`");
			stmt.execute("insert into sistema (limiteTemperaturaMax, limiteTemperaturaMin, limiteHumidadeMax, limiteHumidadeMin, limiteLuminosidadeMax, margemPico, timeAfterAlert, percentagemMargem) values ("+ tmpmax +", "+ tmpmin +", "+ hummax +", "+ hummin +", "+ cell +", "+ margempico +", "+time+", "+margempercentagem+")");


		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
