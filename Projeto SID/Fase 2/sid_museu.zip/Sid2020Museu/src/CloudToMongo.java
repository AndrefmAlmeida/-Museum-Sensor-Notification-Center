import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import com.mongodb.*;
import com.mongodb.util.JSON;
import java.util.*;
import java.io.*;
import javax.swing.*;

@SuppressWarnings("deprecation")
public class CloudToMongo implements MqttCallback {


	//	Variables

	MqttClient mqttclient;
	static MongoClient mongoClient;
	static DB db;
	static DBCollection mongocol_treated;
	static DBCollection mongocol_faulty;
	static String cloud_server = new String();
	static String cloud_topic = new String();
	static String mongo_host = new String();
	static String mongo_database = new String();
	static String mongo_collection_treated = new String();
	static String mongo_collection_faulty = new String();
	ArrayList<Double> lastTmp = new ArrayList<Double>(3);
	ArrayList<Double> lastHum = new ArrayList<Double>(3);
	static String margemPico = new String();



	//    Main

	public static void main(String[] args) {

		try {
			Properties p = new Properties();
			p.load(new FileInputStream("C:\\Users\\Andre\\Desktop\\sid\\java\\cloudToMongo.ini"));
			cloud_server = p.getProperty("cloud_server");
			cloud_topic = p.getProperty("cloud_topic");
			mongo_host = p.getProperty("mongo_host");
			mongo_database = p.getProperty("mongo_database");
			mongo_collection_treated = p.getProperty("mongo_collection_treated");
			mongo_collection_faulty = p.getProperty("mongo_collection_faulty");
			margemPico = p.getProperty("margemPico");

		} catch (Exception e) {

			System.out.println("Error reading CloudToMongo.ini file " + e);
			JOptionPane.showMessageDialog(null, "The CloudToMongo.inifile wasn't found.", "CloudToMongo",
					JOptionPane.ERROR_MESSAGE);
		}

		new CloudToMongo().connectCloud();
		new CloudToMongo().connectMongo();
	}

	//    Connect to MQTT Cloud

	public void connectCloud() {
		int i;
		try {
			i = new Random().nextInt(100000);
			mqttclient = new MqttClient(cloud_server, "CloudToMongo_" + String.valueOf(i) + "_" + cloud_topic);
			mqttclient.connect();
			mqttclient.setCallback(this);
			mqttclient.subscribe(cloud_topic);
		} catch (MqttException e) {
			e.printStackTrace();
		}
	}

	//	Connect to MongoDB

	public void connectMongo() {
		mongoClient = new MongoClient(new MongoClientURI(mongo_host));
		db = mongoClient.getDB(mongo_database);
		mongocol_treated = db.getCollection(mongo_collection_treated);
		mongocol_faulty = db.getCollection(mongo_collection_faulty);
	}

	//	Message received from MQTT Cloud

	@Override
	public void messageArrived(String topic, MqttMessage c)
			throws Exception {
		try {
			String Message = c.toString();
			String FilteredMessage = replaceSlash(Message);
			DBObject document_json;
			document_json = (DBObject) JSON.parse(FilteredMessage);
			formatJSON(document_json);
			formatTime(document_json);

			if (verifyTmp(document_json)) {
				lastTmp.add(Double.parseDouble(document_json.get("tmp").toString()));	
			}

			if (verifyHum(document_json)) {
				lastHum.add(Double.parseDouble(document_json.get("hum").toString()));	
			}

			System.out.println(document_json.toString());
			verifyAll(document_json);


		} catch (Exception e) {
			System.out.println(e);
		}
	}


	public Double getMedian(ArrayList aux){
		Double zero = (Double) aux.get(0);
		Double um = (Double) aux.get(1);
		Double dois = (Double) aux.get(2);

		List <Double> nv = new ArrayList<Double>();
		nv.add(zero);
		nv.add(um);
		nv.add(dois);

		Collections.sort(nv);
		Double r = nv.get(1);
		return r;
	}

	public void fixTmp(DBObject obj) {
		obj.removeField("tmp");
		obj.put("tmp", "NULL");
	}

	public void fixHum(DBObject obj) {
		obj.removeField("hum");
		obj.put("hum", "NULL");
	}

	
//	M�todo que verifica se existem picos de Temperatura e/ou Humidade

	public void verifyPico(DBObject document_json) {
		boolean picoTmp = false;
		boolean picoHum = false;
		if (lastTmp.size() > 3 || lastHum.size() > 3) {
			if (lastTmp.size() > 3) {
				lastTmp.remove(0);
				//			Pico Tmp
				if (Math.abs((getMedian(lastTmp) - Double.parseDouble(document_json.get("tmp").toString()))) > Double.parseDouble(margemPico)) {
					picoTmp = true;
					document_json.put("PicoDeTemperatura", Double.parseDouble(document_json.get("tmp").toString()));
				}
			} 

			if (lastHum.size() > 3) {
				lastHum.remove(0);
				//			Pico Hum
				if (Math.abs((getMedian(lastHum) - Double.parseDouble(document_json.get("hum").toString()))) > Double.parseDouble(margemPico)) {
					picoHum = true;
					document_json.put("PicoDeHumidade", Double.parseDouble(document_json.get("hum").toString()));
				}
			}
		} 
		if (picoTmp || picoHum) {
			mongocol_faulty.insert(document_json);
			if (picoTmp) {
				document_json.removeField("PicoDeTemperatura");
				fixTmp(document_json);
				picoTmp = false;
			}
			if (picoHum) {
				document_json.removeField("PicoDeHumidade");
				fixHum(document_json);
				picoHum= false;
			}
		}
		if (picoTmp && picoHum == false) {
			mongocol_treated.insert(document_json);
		}
		else {
			mongocol_treated.insert(document_json);
		}
	}
	
	
	
//	M�todo que verifica a elegibilidade dos valores recebidos pelo sensor

	public void verifyAll(DBObject obj) {
		int falseCounter = 0;
		boolean errorTmp = false;
		boolean errorHum = false;
		boolean errorCell = false;
		boolean errorMov = false;

		if(verifyTmp(obj)) {			
		}else {
			falseCounter++;
			errorTmp=true;
		}

		if(verifyHum(obj)) {
		}else {
			falseCounter++;
			errorHum=true;
		}

		if(verifyCell(obj)) {
		}else {
			falseCounter++;
			errorCell=true;
		}

		if(verifyMov(obj)) {
		}else {
			falseCounter++;
			errorMov=true;
		}

		if(verifyTmp(obj) && verifyHum(obj) && verifyCell(obj) && verifyMov(obj)) {
			verifyPico(obj);
		}


		while(falseCounter > 0) {

			String aux = "Sensor de ";
			String aux2 = "";

			if(errorTmp) {
				aux2 += "Temperatura ";
			}
			if(errorHum) {
				aux2 += "Humidade ";
			}
			if(errorCell) {
				aux2 += "Luminosidade ";
			}
			if(errorMov) {
				aux2 += "Movimento ";
			}

			aux2 = aux2.replaceAll("\\s", ", ");

			aux2.lastIndexOf(",");
			aux2 = aux2.substring(0, aux2.lastIndexOf(","));

			aux2 += " com erro.";
			aux += aux2;

			obj.put("Descri��o", aux);

			mongocol_faulty.insert(obj);

			obj.removeField("Descri��o");


			if(errorTmp) {
				obj.removeField("tmp");
				obj.put("tmp", "NULL");
				errorTmp = false;
				falseCounter--;
			}	

			if(errorHum) {
				obj.removeField("hum");
				obj.put("hum", "NULL");
				errorHum = false;
				falseCounter--;
			}	
			if(errorCell) {
				obj.removeField("cell");
				obj.put("cell", "NULL");
				errorCell = false;
				falseCounter--;

			}	

			if(errorMov) {
				obj.removeField("mov");
				obj.put("mov", "NULL");
				errorMov = false;
				falseCounter--;
			}	

			verifyPico(obj);
		}

	}



	public boolean verifyTmp( DBObject obj) {
		if (obj.toString().contains("tmp")) {
			if(isNumeric(obj.get("tmp").toString())){	
				return true;
			}else {
				return false;
			}
		}
		return false;
	}

	public boolean verifyHum(DBObject obj) {
		if (obj.toString().contains("hum")) {
			if(isNumeric(obj.get("hum").toString()) && (Double.parseDouble(obj.get("hum").toString())) > 0) {
				return true;
			}else{
				return false;
			}
		}
		return false;
	}

	public boolean verifyCell(DBObject obj) {
		if (obj.toString().contains("cell")) {
			if(isNumeric(obj.get("cell").toString())) {
				if((Double.parseDouble(obj.get("cell").toString())) > 0.0) {
					return true;
				} else {
					return false;
				}
			}
			return false;

		}
		return false;
	}


	public boolean verifyMov(DBObject obj) {
		if (obj.toString().contains("mov")) {
			try {
				if(isNumeric(obj.get("mov").toString()) && (Integer.parseInt(obj.get("mov").toString())) == 0 || (Integer.parseInt(obj.get("mov").toString())) == 1 ) {
					return true;
				}else{
					return false;
				}
			}catch(NumberFormatException e) {
				return false;
			}
		}
		return false;
	}

	public static boolean isNumeric(String str) { 
		try {  
			Double.parseDouble(str);  
			return true;
		} catch(Exception e){
			return false;  
		}  
	}


	//	Methods not used

	@Override
	public void connectionLost(Throwable cause) {
	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken token) {
	}

	//	Replace / for - on date 

	public String replaceSlash (String message) {
		message = message.replaceAll("/", "-");
		message = message.replaceAll("\"\", ", "\",\"");
		return message;
	}


	public void formatJSON (DBObject document_json) {
		String data = document_json.get("dat").toString();
		String[] nd = data.split("-");
		String temp = nd[0];
		nd[0] = nd[2];
		nd[2]= temp;
		String nov = nd[0] + "-" + nd[1]+ "-" + nd[2];
		document_json.removeField("dat");
		document_json.put("dat", nov);
		document_json.removeField("sens");
	}
	
	public void formatTime (DBObject document_json) {
		String data = document_json.get("tim").toString();
		String[] nd = data.split(":");
		int temp = Integer.parseInt(nd[0]);
		String nov = temp+1 + ":" + nd[1]+ ":" + nd[2];
		document_json.removeField("tim");
		document_json.put("tim", nov);
	}
}